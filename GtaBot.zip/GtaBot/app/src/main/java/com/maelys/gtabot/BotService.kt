package com.maelys.gtabot

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Capture l'écran, analyse quelques pixels, puis agit via TapService. */
class BotService : Service() {

    // ====== À CALIBRER (positions en % de l'écran, 0.0 à 1.0) ======
    // Joystick de GTA (en bas à gauche) : centre et direction "avant"
    private val joyX = 0.15f; private val joyY = 0.75f; private val joyUp = 0.55f
    // Points d'observation : le texte de l'overlay affiche leur couleur pour t'aider à régler les règles
    private val samples = listOf(
        "vie" to (0.90f to 0.06f),
        "marqueur" to (0.50f to 0.50f),
        "bouton" to (0.85f to 0.80f)
    )
    // Règles : si le pixel (x,y) ressemble à la couleur (r,g,b) à ±tol, on touche (tx,ty)
    private data class Rule(val name: String, val x: Float, val y: Float,
                            val r: Int, val g: Int, val b: Int, val tol: Int,
                            val tx: Float, val ty: Float)
    private val rules = listOf(
        // Exemple à adapter : si un bouton d'action jaune apparaît, appuie dessus
        Rule("bouton jaune", 0.85f, 0.80f, 255, 200, 0, 60, 0.85f, 0.80f)
    )
    // ===============================================================

    private val handler = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var w = 0; private var h = 0
    private var forward = false
    private lateinit var info: TextView
    private lateinit var wm: WindowManager
    private lateinit var overlay: LinearLayout

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "GTA Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot").setContentTitle("GTA Bot actif")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, handler)
        }
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val b = wm.currentWindowMetrics.bounds; w = b.width(); h = b.height()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("cap", w, h, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        buildOverlay()
        handler.post(loop)
        return START_NOT_STICKY
    }

    private fun buildOverlay() {
        overlay = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0x99000000.toInt()) }
        info = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); textSize = 11f }
        val fwd = Button(this).apply { text = "Avancer: OFF"; setOnClickListener { forward = !forward; text = "Avancer: " + if (forward) "ON" else "OFF" } }
        val stop = Button(this).apply { text = "Stop"; setOnClickListener { stopSelf() } }
        overlay.addView(info); overlay.addView(fwd); overlay.addView(stop)
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL }
        wm.addView(overlay, lp)
    }

    private val loop = object : Runnable {
        override fun run() {
            analyse()
            handler.postDelayed(this, 500)
        }
    }

    private fun analyse() {
        val img = reader?.acquireLatestImage() ?: return
        try {
            val p = img.planes[0]; val buf = p.buffer
            fun px(xf: Float, yf: Float): Triple<Int, Int, Int> {
                val x = (xf * (w - 1)).toInt(); val y = (yf * (h - 1)).toInt()
                val o = y * p.rowStride + x * p.pixelStride
                return Triple(buf.get(o).toInt() and 255, buf.get(o + 1).toInt() and 255, buf.get(o + 2).toInt() and 255)
            }
            info.text = samples.joinToString("\n") { (n, pos) -> val c = px(pos.first, pos.second); "$n: ${c.first},${c.second},${c.third}" }
            val tap = TapService.instance ?: run { info.append("\n⚠ accessibilité OFF"); return }
            for (r in rules) {
                val c = px(r.x, r.y)
                if (Math.abs(c.first - r.r) < r.tol && Math.abs(c.second - r.g) < r.tol && Math.abs(c.third - r.b) < r.tol) {
                    tap.tap(r.tx * w, r.ty * h); info.append("\n→ ${r.name}")
                }
            }
            if (forward) tap.swipe(joyX * w, joyY * h, joyX * w, joyUp * h, 450)
        } finally { img.close() }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        runCatching { wm.removeView(overlay) }
        projection?.stop(); super.onDestroy()
    }
}
